package edu.handong.csee.java.hw5.engines;

import edu.handong.csee.java.hw5.util.InputChecker;

public class GCDEngine implements Computable {
    private int num1;

    public int getNum1() {
        return num1;
    }
    private int num2;

    public int getNum2() {
        return num2;
    }
    private double result;

    @Override
    public void setInput(String[] args) {
        if (args.length < 3) {
            InputChecker.printErrorMesssageForTheNumberOfRequiredInputsAndExit(engineName, 2);
        }

        try {
            num1 = Integer.parseInt(args[1]);
            num2 = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            System.out.println("The input value should be a valid integer for " + engineName + ".");
            System.exit(0);
        }

        if (num1 < 0 || num2 < 0) {
            InputChecker.printErrorMesssageForNegativeInputsAndExit(engineName);
        }

    }

    @Override
    public void compute() {
        int a = num1;
        int b = num2;

        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }

        result = a;

    }

    @Override
    public double getResult() {
        return (double) result;
    }
}
