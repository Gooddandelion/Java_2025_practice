package edu.handong.csee.java.hw5.engines;

import javax.xml.transform.Result;

public interface Computable {

    public void setInput(String[] args); // 입력값을 설정

    public void compute(); // 계산 수행

    public double getResult(); // 결과 값 반환

}
