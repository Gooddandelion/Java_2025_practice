package edu.handong.csee.java.hw5.engines;

import edu.handong.csee.java.hw5.util.InputChecker;

public class MaxEngine implements Computable {
    private double[] num;

    public double[] getNum() {
        return num;
    }
    private double result;

    @Override
    public void setInput(String[] args) {
        if( args.length < 3 ) {
            InputChecker.printErrorMesssageForTheNumberOfRequiredInputsAndExit(engineName, 2);
        }

        num = new double[args.length - 1];

        for (int i = 1; i < args.length; i++) {
            try {
                num[i - 1] = Double.parseDouble(args[i]);
            } catch (NumberFormatException e) {
                System.out.println("The input value should be a valid number for " + engineName + ".");
                System.exit(0);
            }
        }
    }

    @Override
    public void compute() {
        result = num[0];

        for (int i = 1; i < num.length; i++) {
            result = Math.max(result, num[i]);
        }
    }

    @Override
    public double getResult() {
        return result;
    }
}
