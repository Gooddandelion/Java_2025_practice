package edu.handong.csee.java.hw5.engines;

import edu.handong.csee.java.hw5.util.InputChecker;

public class FactorialEngine implements Computable {
    private int num;

    public int getNum() {
        return num;
    }
    private double result;
    @Override
    public void setInput(String[] args) {
        try {
            num = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("The input value should be a valid integer for " + engineName + ".");
            System.exit(0);
        }

        if (num < 0) {
            InputChecker.printErrorMesssageForNegativeInputsAndExit(engineName);
        }
    }

    @Override
    public void compute() {
        result = 1;
        for(int i = 2; i <= num; i++) {
            result = result*i;
        }

    }

    @Override
    public double getResult() {
        return result;
    }
}
