package edu.handong.csee.java.hw5.engines;

import edu.handong.csee.java.hw5.util.InputChecker;

public class SphereVolEngine implements Computable {
    private double num;

    public double getNum() {
        return num;
    }
    private double result;
    @Override
    public void setInput(String[] args) {
        try {
            num = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("The input value should be a valid integer for " + engineName + ".");
            System.exit(0);
        }

        if (num < 0) {
            InputChecker.printErrorMesssageForNegativeInputsAndExit(engineName);
        }

    }

    @Override
    public void compute() {
        result = (4.0/3.0) * Math.pow(num,3) * Math.PI;

    }

    @Override
    public double getResult() {
        return result;
    }
}
